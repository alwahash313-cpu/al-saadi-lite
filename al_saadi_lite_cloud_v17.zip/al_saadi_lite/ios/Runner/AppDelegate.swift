import UIKit
import Flutter
import AVFoundation

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    let controller = window?.rootViewController as! FlutterViewController
    let channel = FlutterMethodChannel(name: "com.alsaadi/media", binaryMessenger: controller.binaryMessenger)
    channel.setMethodCallHandler { call, result in
      guard let args = call.arguments as? [String: Any] else { result(FlutterError(code: "ARGS", message: "Invalid arguments", details: nil)); return }
      switch call.method {
      case "trimVideo":
        guard let input = args["input"] as? String, let output = args["output"] as? String,
              let start = args["startMs"] as? Int, let end = args["endMs"] as? Int else { result(FlutterError(code: "ARGS", message: "Missing arguments", details: nil)); return }
        self.trim(input: input, output: output, startMs: start, endMs: end, result: result)
      case "mergeVideos":
        guard let inputs = args["inputs"] as? [String], let output = args["output"] as? String else { result(FlutterError(code: "ARGS", message: "Missing arguments", details: nil)); return }
        self.merge(inputs: inputs, output: output, result: result)
      case "speedVideo":
        guard let input = args["input"] as? String, let output = args["output"] as? String,
              let speed = args["speed"] as? Double else { result(FlutterError(code: "ARGS", message: "Missing arguments", details: nil)); return }
        self.speed(input: input, output: output, speed: speed, result: result)
      case "copyVideo":
        guard let input = args["input"] as? String, let output = args["output"] as? String else { result(FlutterError(code: "ARGS", message: "Missing arguments", details: nil)); return }
        do { try FileManager.default.removeItem(atPath: output); try FileManager.default.copyItem(atPath: input, toPath: output); result(["path": output, "durationMs": 0]) } catch { result(FlutterError(code: "COPY", message: error.localizedDescription, details: nil)) }
      default: result(FlutterMethodNotImplemented)
      }
    }
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  private func merge(inputs: [String], output: String, result: @escaping FlutterResult) {
    let assets = inputs.map { AVURLAsset(url: URL(fileURLWithPath: $0)) }
    let composition = AVMutableComposition()
    guard let videoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { result(FlutterError(code: "COMPOSITION", message: "Cannot create video track", details: nil)); return }
    let audioTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid)
    var cursor = CMTime.zero
    do {
      for asset in assets {
        let duration = asset.duration
        if let v = asset.tracks(withMediaType: .video).first { try videoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: v, at: cursor) }
        if let a = asset.tracks(withMediaType: .audio).first { try audioTrack?.insertTimeRange(CMTimeRange(start: .zero, duration: duration), of: a, at: cursor) }
        cursor = CMTimeAdd(cursor, duration)
      }
    } catch { result(FlutterError(code: "COMPOSITION", message: error.localizedDescription, details: nil)); return }
    try? FileManager.default.removeItem(atPath: output)
    guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else { result(FlutterError(code: "EXPORT", message: "Export unavailable", details: nil)); return }
    session.outputURL = URL(fileURLWithPath: output); session.outputFileType = .mp4
    session.exportAsynchronously {
      DispatchQueue.main.async {
        if session.status == .completed { result(["path": output, "durationMs": Int(cursor.seconds * 1000)]) }
        else { result(FlutterError(code: "EXPORT", message: session.error?.localizedDescription ?? "Merge failed", details: nil)) }
      }
    }
  }

  private func speed(input: String, output: String, speed: Double, result: @escaping FlutterResult) {
    guard speed > 0.05 && speed <= 8.0 else { result(FlutterError(code: "ARGS", message: "Speed must be between 0.05x and 8x", details: nil)); return }
    let asset = AVURLAsset(url: URL(fileURLWithPath: input))
    let composition = AVMutableComposition()
    guard let sourceVideo = asset.tracks(withMediaType: .video).first,
          let video = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else { result(FlutterError(code: "COMPOSITION", message: "Video track unavailable", details: nil)); return }
    let sourceRange = CMTimeRange(start: .zero, duration: asset.duration)
    do {
      try video.insertTimeRange(sourceRange, of: sourceVideo, at: .zero)
      let scaledDuration = CMTimeMultiplyByFloat64(asset.duration, multiplier: 1.0 / speed)
      video.scaleTimeRange(CMTimeRange(start: .zero, duration: asset.duration), toDuration: scaledDuration)
      if let sourceAudio = asset.tracks(withMediaType: .audio).first, let audio = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
        try audio.insertTimeRange(sourceRange, of: sourceAudio, at: .zero)
        audio.scaleTimeRange(CMTimeRange(start: .zero, duration: asset.duration), toDuration: scaledDuration)
      }
      try? FileManager.default.removeItem(atPath: output)
      guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else { result(FlutterError(code: "EXPORT", message: "Export unavailable", details: nil)); return }
      session.outputURL = URL(fileURLWithPath: output); session.outputFileType = .mp4
      session.exportAsynchronously {
        DispatchQueue.main.async {
          if session.status == .completed { result(["path": output, "durationMs": Int(scaledDuration.seconds * 1000)]) }
          else { result(FlutterError(code: "EXPORT", message: session.error?.localizedDescription ?? "Speed export failed", details: nil)) }
        }
      }
    } catch { result(FlutterError(code: "COMPOSITION", message: error.localizedDescription, details: nil)) }
  }

  private func trim(input: String, output: String, startMs: Int, endMs: Int, result: @escaping FlutterResult) {
    let asset = AVURLAsset(url: URL(fileURLWithPath: input))
    let start = CMTime(value: CMTimeValue(startMs), timescale: 1000)
    let duration = CMTime(value: CMTimeValue(endMs - startMs), timescale: 1000)
    guard let session = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else { result(FlutterError(code: "EXPORT", message: "Export unavailable", details: nil)); return }
    try? FileManager.default.removeItem(atPath: output)
    session.outputURL = URL(fileURLWithPath: output); session.outputFileType = .mp4; session.timeRange = CMTimeRange(start: start, duration: duration)
    session.exportAsynchronously {
      DispatchQueue.main.async {
        if session.status == .completed { result(["path": output, "durationMs": endMs - startMs]) }
        else { result(FlutterError(code: "EXPORT", message: session.error?.localizedDescription ?? "Export failed", details: nil)) }
      }
    }
  }
}
